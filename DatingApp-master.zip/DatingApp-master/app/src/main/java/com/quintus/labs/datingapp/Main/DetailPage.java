package com.quintus.labs.datingapp.Main;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.quintus.labs.datingapp.R;
import com.quintus.labs.datingapp.databinding.ActivityDetailPageBinding;

public class DetailPage extends AppCompatActivity {
    ActivityDetailPageBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= ActivityDetailPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.backBtn.setOnClickListener(v -> {
            onBackPressed();
        });
    }
}