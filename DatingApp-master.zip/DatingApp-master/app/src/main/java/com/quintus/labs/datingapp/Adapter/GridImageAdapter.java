package com.quintus.labs.datingapp.Adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import com.bumptech.glide.Glide;
import com.quintus.labs.datingapp.Main.Cards;
import com.quintus.labs.datingapp.Main.DetailPage;
import com.quintus.labs.datingapp.R;


import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class GridImageAdapter extends ArrayAdapter<Cards> {
    private static final String TAG = "GridImageAdapter";

    private Context mContext;
    private LayoutInflater mInflater;
    private int layoutResource;
    private String mAppend;
    private ArrayList<Cards> imgURLs;

    public GridImageAdapter(Context context, int layoutResource, String append, ArrayList<Cards> imgURLs) {
        super(context, layoutResource, imgURLs);
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mContext = context;
        this.layoutResource = layoutResource;
        mAppend = append;
        this.imgURLs = imgURLs;
    }

    static class ViewHolder{
        ImageView pimage, video, comment, like;
        TextView name;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        /*
        Viewholder build pattern (Similar to recyclerview)
         */
        final ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(layoutResource, parent, false);
            holder = new ViewHolder();
            holder.pimage = convertView.findViewById(R.id.profileImage);
            holder.video =  convertView.findViewById(R.id.videoCalBtn);
            holder.comment= convertView.findViewById(R.id.commentbtn);
          //  holder.andExoPlayerView= convertView.findViewById(R.id.andExoPlayerView);
            holder.like= convertView.findViewById(R.id.likebtn);

            convertView.setTag(holder);
        }
        else{
            holder = (ViewHolder) convertView.getTag();
        }


        Log.d(TAG, "getView: "+imgURLs.get(position).getProfileImageUrl());
          //imgURL.trim();
        Glide.with(mContext).load(imgURLs.get(position).getProfileImageUrl()).into(holder.pimage);
      holder.pimage.setOnClickListener(v -> {
          Intent intent= new Intent(mContext, DetailPage.class);
          mContext.startActivity(intent);
      });
        return convertView;
    }
}
